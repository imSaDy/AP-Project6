#pragma once 

#include "global_stuff.hpp"
#include "user.hpp"

class Admin : public User {
public: 
    Admin(); 
    void print(); 
    void print_info();
    void print_personal_page(); 
private:

}; 