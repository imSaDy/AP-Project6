#include "post.hpp"

Post::Post(string id_){
    id = id_;
}