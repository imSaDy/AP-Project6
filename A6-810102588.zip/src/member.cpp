#include "member.hpp"

Member::Member(string id_, MemberType member_type_){
    id = id_ ; 
    member_type = member_type_ ; 
}