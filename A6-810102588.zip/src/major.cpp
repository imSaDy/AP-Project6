#include "major.hpp"

Major::Major(string id_, string name_){
    id = id_ ;
    name = name_ ; 
}
